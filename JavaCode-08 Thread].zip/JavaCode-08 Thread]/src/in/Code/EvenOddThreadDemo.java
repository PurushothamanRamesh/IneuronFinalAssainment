package in.Code;
/*
	Write a Java program that creates two threads. The first thread should print even
numbers between 1 and 10, and the second thread should print odd numbers
between 1 and 10.
	 
 */

public class EvenOddThreadDemo {
	public static void main(String[] args) {
		Thread evenThread = new Thread(new EvenRunnable());
		Thread oddThread = new Thread(new OddRunnable());

		evenThread.start();
		oddThread.start();
	}
}

class EvenRunnable implements Runnable {
	public void run() {
		for (int i = 2; i <= 10; i += 2) {
			System.out.println(i);
		}
	}
}

class OddRunnable implements Runnable {
	public void run() {
		for (int i = 1; i <= 9; i += 2) {
			System.out.println(i);
		}
	}
}
