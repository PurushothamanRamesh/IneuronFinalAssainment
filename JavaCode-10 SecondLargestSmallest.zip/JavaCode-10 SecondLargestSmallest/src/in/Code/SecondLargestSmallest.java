package in.Code;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/*
	Write a Java program that reads a set of integers from the user and stores them in a
List. The program should then find the second largest and second smallest elements
in the List.
	 
 */
public class SecondLargestSmallest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Integer> numbers = new ArrayList<>();

        System.out.print("Enter the number of integers: ");
        int count = scanner.nextInt();

        for (int i = 0; i < count; i++) {
            System.out.print("Enter an integer: ");
            int num = scanner.nextInt();
            numbers.add(num);
        }

        int secondLargest = findSecondLargest(numbers);
        int secondSmallest = findSecondSmallest(numbers);

        System.out.println("Second largest number: " + secondLargest);
        System.out.println("Second smallest number: " + secondSmallest);
    }

    public static int findSecondLargest(List<Integer> numbers) {
        if (numbers.size() < 2) {
            throw new IllegalArgumentException("List must have at least 2 elements");
        }

        List<Integer> sortedList = new ArrayList<>(numbers);
        Collections.sort(sortedList);

        return sortedList.get(sortedList.size() - 2);
    }

    public static int findSecondSmallest(List<Integer> numbers) {
        if (numbers.size() < 2) {
            throw new IllegalArgumentException("List must have at least 2 elements");
        }

        List<Integer> sortedList = new ArrayList<>(numbers);
        Collections.sort(sortedList);

        return sortedList.get(1);
    }
}