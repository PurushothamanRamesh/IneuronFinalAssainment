package in.Code;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class CRUDOperations {
   

    public CRUDOperations(Connection connection) {
        this.connection = connection;
    }

    
    Connection connection = null;
	PreparedStatement pstmt = null;
	ResultSet resultSet = null;
	Scanner scanner = new Scanner(System.in);

    public void run() throws SQLException {
        while (true) {
            System.out.println("Choose an operation: ");
            System.out.println("1. Add record");
            System.out.println("2. View records");
            System.out.println("3. Update record");
            System.out.println("4. Delete record");
            System.out.println("5. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    addRecord();
                    break;
                case 2:
                    viewRecords();
                    break;
                case 3:
                    updateRecord();
                    break;
                case 4:
                    deleteRecord();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    public  void addRecord() throws SQLException {
        System.out.println("Enter employee name: ");
        String name = scanner.nextLine();
        System.out.println("Enter employee age: ");
        int age = scanner.nextInt();

        String insertQuery = "INSERT INTO employees (name, age) VALUES (?, ?)";
        pstmt = connection.prepareStatement(insertQuery);
        pstmt.setString(1, name);
        pstmt.setInt(2, age);
        pstmt.executeUpdate();

        System.out.println("Record added successfully.");
    }

    public void viewRecords() throws SQLException {
        String selectQuery = "SELECT * FROM employees";
        pstmt = connection.prepareStatement(selectQuery);
        resultSet = pstmt.executeQuery();

        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String name = resultSet.getString("name");
            int age = resultSet.getInt("age");

            System.out.println("ID: " + id + ", Name: " + name + ", Age: " + age);
        }

        resultSet.close();
        pstmt.close();
    }

    public void updateRecord() throws SQLException {
        System.out.println("Enter the ID of the employee to update: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.println("Enter the new name of the employee: ");
        String newName = scanner.nextLine();

        System.out.println("Enter the new age of the employee: ");
        int newAge = scanner.nextInt();

        String updateQuery = "UPDATE employees SET name = ?, age = ? WHERE id = ?";
        pstmt = connection.prepareStatement(updateQuery);
        pstmt.setString(1, newName);
        pstmt.setInt(2, newAge);
        pstmt.setInt(3, id);
        int rowsUpdated = pstmt.executeUpdate();

        if (rowsUpdated > 0) {
            System.out.println("Record updated successfully.");
        } else {
            System.out.println("Record not found or update failed.");
        }

        pstmt.close();
    }

    public void deleteRecord() throws SQLException {
        System.out.println("Enter the ID of the employee to delete: ");
        int id = scanner.nextInt();

        String deleteQuery = "DELETE FROM employees WHERE id = ?";
         pstmt = connection.prepareStatement(deleteQuery);
        pstmt.setInt(1, id);
        int rowsDeleted = pstmt.executeUpdate();

        if (rowsDeleted > 0) {
            System.out.println("Record deleted successfully.");
        } else {
            System.out.println("Record not found or delete failed.");
        }

        pstmt.close();
    }
}

