package in.Code;

/*
	Write a Java program that uses JDBC to implement a simple CRUD (create, read,
update, delete) application. The program should allow users to add, view, update,
and delete records in a MySQL database table.
	 
 */
import java.sql.Connection;
import java.sql.SQLException;

public class CRUDApplication {
    public static void main(String[] args) {
    	  String jdbcUrl = "jdbc:mysql:///mydatabase";
          String username = "root";
          String password = "root";
          	
        try {
            // Step 1: Create a database connection
            DatabaseConnection dbConnection = new DatabaseConnection(jdbcUrl, username, password);
            Connection connection = dbConnection.getConnection();

            // Step 2: Perform CRUD operations
            CRUDOperations crudOperations = new CRUDOperations(connection);
            crudOperations.run();

            // Step 3: Close the database connection
            dbConnection.closeConnection();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
    
}


    