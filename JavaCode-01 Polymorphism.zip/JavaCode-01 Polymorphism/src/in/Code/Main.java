package in.Code;


/*
	 Write a Java program that uses polymorphism by defining an interface called Shape
	with methods to calculate the area and perimeter of a shape. Then create classes
	that implement the Shape interface for different types of shapes, such as circles and
	triangles.
 
 */

public class Main {
	public static void main(String[] args) {
		Shape circle = new Circle(5.0);
		System.out.println("Circle Area: " + circle.calculateArea());
		System.out.println("Circle Perimeter: " + circle.calculatePerimeter());

		Shape triangle = new Triangle(3.0, 4.0, 5.0);
		System.out.println("Triangle Area: " + triangle.calculateArea());
		System.out.println("Triangle Perimeter: " + triangle.calculatePerimeter());
	}
}