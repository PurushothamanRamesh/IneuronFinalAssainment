package in.Code;

public interface Shape {
	    double calculateArea();
	    double calculatePerimeter();
}
