package in.spartan.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import in.spartan.model.Employee;


public interface IEmployeeService {

	public List<Employee> getAllEmployeesBySorting(String order,String property);
	
	public Page<Employee> getAllEmployeesByPagination(Pageable pageable);
}
