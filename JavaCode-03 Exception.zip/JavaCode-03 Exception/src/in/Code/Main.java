package in.Code;
/*
	Write a Java programme that takes an integer from the user and throws an exception
	if it is negative.Demonstrate Exception handling of same program as solution
	 
 */

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter an integer: ");
            int number = scanner.nextInt();

            if (number < 0) {
                throw new IllegalArgumentException("Negative number not allowed!");
            }

            System.out.println("You entered: " + number);
        } catch (IllegalArgumentException e) {
            System.out.println("Exception caught: " + e.getMessage());
        } 
        catch (Exception e) {
			e.printStackTrace();
		}
        finally {
            scanner.close();
        }
    }
}






