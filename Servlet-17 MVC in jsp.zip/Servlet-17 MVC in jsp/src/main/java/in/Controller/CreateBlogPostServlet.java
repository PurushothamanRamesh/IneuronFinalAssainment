package in.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.Model.Dao;
import in.dto.BlogPost;

@WebServlet("/BlogPostServlet/*")
public class CreateBlogPostServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CreateBlogPostServlet() {
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doProcess(request, response);
	}

	private void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Request URI :: " + request.getRequestURI());
		System.out.println("Path info   :: " + request.getPathInfo());
		
		if (request.getRequestURI().endsWith("createBlogPost")) {
			String title = request.getParameter("title");
	        String description = request.getParameter("description");
	        String content = request.getParameter("content");
	        BlogPost post = new BlogPost(title, description, content);
	        String createpost = new Dao().createpost(post);
			System.out.println(createpost);
		}
		if (request.getRequestURI().endsWith("viewBlogPosts")) {
			List<BlogPost> blogPosts = new Dao().viewBlogPosts();
			request.setAttribute("blogPosts", blogPosts);
		    request.getRequestDispatcher("../viewBlogPosts.jsp").forward(request, response);
		}
		
	}
}
