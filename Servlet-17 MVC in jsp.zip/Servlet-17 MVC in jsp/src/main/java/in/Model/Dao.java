package in.Model;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import in.Code.util.JdbcUtil;
import in.dto.BlogPost;

public class Dao {
	Connection connection = null;
	PreparedStatement pstmt = null;
	ResultSet resultSet = null;
	private ArrayList<BlogPost> arrayList;

	public String createpost(BlogPost user) {
		try {
			connection = JdbcUtil.getJdbcConnection();
			

			String sqlInsertQuery="INSERT INTO blog_posts (title, description, content) VALUES (?, ?, ?)";
			if (connection != null)
				pstmt = connection.prepareStatement(sqlInsertQuery);

			if (pstmt != null) {
				pstmt.setString(1, user.getTitle());
				pstmt.setString(2, user.getDescription());
				pstmt.setString(3, user.getContent());
				int rowAffected = pstmt.executeUpdate();
				if (rowAffected == 1) {
					return "success";
				}
			}
			} catch (SQLException | IOException e) {
					e.printStackTrace();
			}

	return"failure";
}
	
	public List<BlogPost> viewBlogPosts(){
		 arrayList = new ArrayList<>();
		 try {
				connection = JdbcUtil.getJdbcConnection();

				String sqlInsertQuery="SELECT * FROM blog_posts";
				if (connection != null) {
					 pstmt = connection.prepareStatement(sqlInsertQuery);
				}
				if (pstmt != null) {
					resultSet = pstmt.executeQuery();
				}
				while(resultSet.next()){  
						String title = resultSet.getString("title");
		                String description = resultSet.getString("description");
		                String content = resultSet.getString("content");
		                BlogPost blogPost = new BlogPost(title, description, content);
		                arrayList.add(blogPost);
				} 
			} catch (Exception  e) {
				e.printStackTrace();
			}
		return arrayList;
	 }
		
	}


