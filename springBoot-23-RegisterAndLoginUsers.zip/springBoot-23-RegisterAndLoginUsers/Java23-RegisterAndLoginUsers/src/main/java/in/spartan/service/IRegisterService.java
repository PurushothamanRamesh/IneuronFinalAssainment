package in.spartan.service;

import in.spartan.model.Login;
import in.spartan.model.Register;

public interface IRegisterService {

	public String registerService(Register register);
	public String validateUser(Login login);
}
