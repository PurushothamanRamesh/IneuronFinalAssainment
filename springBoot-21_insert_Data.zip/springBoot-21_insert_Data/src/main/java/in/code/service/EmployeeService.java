package in.code.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.code.Dao.EmployeeRepository;
import in.code.bo.EmployeeSpring;

@Service
public class EmployeeService {
	@Autowired
    private  EmployeeRepository employeeRepository;

    public EmployeeSpring createEmployee(EmployeeSpring employee) {
    	
        return employeeRepository.save(employee);
    }
}
