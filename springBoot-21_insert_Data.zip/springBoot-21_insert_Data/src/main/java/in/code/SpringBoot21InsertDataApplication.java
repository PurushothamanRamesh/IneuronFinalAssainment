package in.code;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import in.code.bo.EmployeeSpring;
import in.code.service.EmployeeService;

@SpringBootApplication
public class SpringBoot21InsertDataApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext applicationContext = SpringApplication.run(SpringBoot21InsertDataApplication.class, args);
		EmployeeService service = applicationContext.getBean(EmployeeService.class);
		EmployeeSpring employeeSpring = new EmployeeSpring(2L, "dsfd", 45);
		service.createEmployee(employeeSpring);
	}

}
