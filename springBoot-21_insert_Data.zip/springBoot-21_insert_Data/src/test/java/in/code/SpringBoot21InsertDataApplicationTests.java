package in.code;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot21InsertDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
