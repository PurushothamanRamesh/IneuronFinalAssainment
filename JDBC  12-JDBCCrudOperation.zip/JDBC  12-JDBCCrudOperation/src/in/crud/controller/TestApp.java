package in.crud.controller;

import in.crud.daoFactory.StudentDaoFactory;
import in.crud.datatransferobject.Student;
import in.crud.persistencelayer.IStudentDao;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class TestApp {
//Controller logic
	public static void main(String[] args) throws IOException {
		Scanner s=new Scanner(System.in);
		
		System.out.println("To perform Operation in Student Database");
		System.out.println("==========================================");
		
		while(true)
		{
			System.out.println();
			System.out.println();
			System.out.println("1. Insert new student record");
			System.out.println("2. Search student");
			System.out.println("3. Update Student details");
			System.out.println("4. Delete Student record");
			System.out.println("5. Exit");
			
			
			System.out.println("Enter key value");
			int choice=s.nextInt();
			switch(choice)
			{
			case 1:
				insertOperation();
				break;
			case 2:
				selectOperation();	
				break;
				
			case 3:
				updateOperation();
				break;
			case 4:
				deleteOperation();
				break;
			case 5:
				System.out.println("******* Thanks for using the application *****");
				s.close();
				System.exit(0);
				
			default:System.out.println("Invalid key");
			
			}
		}
	}
	public static void  insertOperation()
	{
		 Scanner scan=new Scanner(System.in);
		 IStudentDao studentService=StudentDaoFactory.getStudentDao();
		 System.out.println("ENTER NAME");
		 String sname=scan.next();
		 System.out.println("ENTER AGE");
		 int sage=scan.nextInt();
		 System.out.println("ENTER ADDRESS");
		 String saddress=scan.next();
		 String msg=studentService.addStudent(sname, sage, saddress);
		 if(msg.equalsIgnoreCase("success"))
		 {
			 System.out.println("Student record inserted successfully");
		 }
		 else
			 System.out.println("Insertion Failed");
		 scan.close();
	}
	public static void selectOperation()
	{
		 Scanner scan=new Scanner(System.in);
		 System.out.println("ENTER ID");
		 int sid=scan.nextInt();
		 IStudentDao studentService=StudentDaoFactory.getStudentDao();
		 Student std=studentService.searchStudent(sid);
		 if(std!=null)
		 {
			 System.out.println("\tID\tNAME\tAGE\tADDRESS");
			 System.out.println("\t"+std.getSid()+"\t"+std.getSname()+"\t"+std.getSage()+"\t"+std.getSaddress());
		 }
		 else
			 System.out.println("Record not found");
		 scan.close();
	}
	public static void updateOperation() throws IOException
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("ENTER ID");
		int sid=Integer.parseInt(br.readLine());
		IStudentDao studentService=StudentDaoFactory.getStudentDao();
		Student std=studentService.searchStudent(sid);
			 Student student=new Student();
			 //Updating
			 if(student!=null)
			 {
				 System.out.println("Student id is :: " + std.getSid());
					student.setSid(std.getSid());
			    System.out.println("To update the current student details");
				System.out.println("Old name: "+std.getSname()+"  Enter new name:");
				String newName=br.readLine();
				if(newName.equals("") || newName=="")
					student.setSname(std.getSname());
				else
					student.setSname(newName);
				System.out.println("Old Age: "+std.getSage()+"  Enter new age:");
				String newAge=br.readLine();
				if(newAge.equals("") || newAge=="")
					student.setSage(std.getSage());
				else
					student.setSage(Integer.parseInt(newAge));
				System.out.println("Old Address: "+std.getSaddress()+"  Enter new address:");
				String newAddress=br.readLine();
				if(newAddress.equals("") || newAddress==null)
					student.setSaddress(std.getSaddress());
				else
					student.setSaddress(newAddress);
				String msg=studentService.updateStudent(student);
				 if(msg.equalsIgnoreCase("success"))
				 {
					 System.out.println("Student record updated successfully");
				 }
				 else
					 System.out.println("Updation Failed");
	        }
			else 
			    System.out.println("Student record not available for the given id  " + sid + " for updation...");
				
	}
	public static void deleteOperation()
	{
		 Scanner scan=new Scanner(System.in);
		 System.out.println("ENTER ID");
		 int sid=scan.nextInt();
		 IStudentDao studentService=StudentDaoFactory.getStudentDao();
		 String msg=studentService.deleteStudent(sid);
		 if(msg.equalsIgnoreCase("Success"))
		 {
			 System.out.println("Record deleted Successfully");
		 }
		 else if(msg.equalsIgnoreCase("Not found"))
			 System.out.println("Record not found");
		 else
			 System.out.println("Deletion failed");
	}
	

}
