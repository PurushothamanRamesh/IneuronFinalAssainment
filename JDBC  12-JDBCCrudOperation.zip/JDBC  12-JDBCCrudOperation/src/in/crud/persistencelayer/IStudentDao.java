package in.crud.persistencelayer;

import in.crud.datatransferobject.Student;

public interface IStudentDao {

	public  String addStudent(String sname,Integer sage,String saddress);
	public Student searchStudent(Integer id);
	public String updateStudent(Student student);
	public String deleteStudent(Integer sid);
}
