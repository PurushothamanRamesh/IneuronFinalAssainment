package in.Code;

/*
	Write a Java program that connects to a MySQL database using JDBC. The program
should read data from a table and display the results in the console.
	 
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MySQLJDBCDemo {
    public static void main(String[] args) {
        String jdbcUrl = "jdbc:mysql:///mydatabase";
        String username = "root";
        String password = "root";
        
        try {
            // Step 1: Load and register the MySQL JDBC driver
           // Class.forName("com.mysql.jdbc.Driver");
            
            // Step 2: Establish a connection to the database
            Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
            
            // Step 3: Create a statement
            Statement statement = connection.createStatement();
            
            // Step 4: Execute the SQL query
            String sqlQuery = "SELECT * FROM mytable";
            ResultSet resultSet = statement.executeQuery(sqlQuery);
            
            // Step 5: Process and display the results
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");
                
                System.out.println("ID: " + id + ", Name: " + name + ", Age: " + age);
            }
            
            // Step 6: Close the resources
            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        catch (Exception e) {
        	e.printStackTrace();
        }
    }
}
