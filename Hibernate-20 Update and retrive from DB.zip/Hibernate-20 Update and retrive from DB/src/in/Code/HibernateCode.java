package in.Code;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import in.Util.HibernateUtil;

public class HibernateCode {
    public static void main(String[] args) throws IOException {
    	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		while (true) {

			System.out.println("1. UPDATE");
			System.out.println("2. RETRIVE");
			System.out.println("3. EXIT");
			System.out.print("ENTER UR CHOICE, PRESS[1/2/3]::  ");
			String option = br.readLine();

			switch (option) {
			case "1":
				UpdateData();
				break;
			case "2":
				retriveData();
				
				break;
			case "3":
				System.out.println("******* Thanks for using the application *****");
				System.exit(0);
			default:
				System.out.println("Invalid option plz try agin with valid options....");
				break;
			}
    }
}
    public static  void retriveData() {
		Session session = null;
		try {
			session = HibernateUtil.getSession();

			@SuppressWarnings("unchecked")
			List<EntityClass> entities = session.createQuery("FROM in.Code.EntityClass").getResultList();

			// process the List Object
			entities.forEach(System.out::println);

		} catch (HibernateException he) {
			he.printStackTrace();
		} finally {
			HibernateUtil.closeSession(session);
			HibernateUtil.closeSessionFactory();
		}
	}
    public static  void UpdateData() {
    	Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		Scanner scan = new Scanner(System.in);

		try {
			session = HibernateUtil.getSession();

			if (session != null)
				transaction = session.beginTransaction();

			if (transaction != null) {
				System.out.println("ENTER THE ID ::");
				int int1 = scan.nextInt();
				System.out.println("ENTER THE Name ::");
				String name = scan.next();
				System.out.println("ENTER THE Place ::");
				String place = scan.next();
				EntityClass entityClass = new EntityClass();
				entityClass.setId(int1);
				entityClass.setName(name);
				entityClass.setPlace(place);
				
				session.saveOrUpdate(entityClass);
				
				flag = true;
			}

		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag) {
				transaction.commit();
				System.out.println("Object updated to database....");
			} else {
				transaction.rollback();
				System.out.println("Object not updated to database...");
			}

			HibernateUtil.closeSession(session);
			HibernateUtil.closeSessionFactory();
		}

    	
    }


}
