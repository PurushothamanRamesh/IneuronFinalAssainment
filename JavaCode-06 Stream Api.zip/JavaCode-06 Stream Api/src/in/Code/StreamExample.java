package in.Code;
/*
	Write a Java programme that takes an integer from the user and throws an exception
	if it is negative.Demonstrate Exception handling of same program as solution
	 
 */

import java.util.Arrays;
import java.util.List;

public class StreamExample {
	public static void main(String[] args) {
        // Sample data set
        List<Integer> numbers = Arrays.asList(5, 2, 10, 8, 3, 1, 6, 4, 9, 7);

        // Sorting the numbers in ascending order
        List<Integer> sortedNumbers = numbers.stream()
                .sorted()
                .toList();

        System.out.println("Sorted numbers: " + sortedNumbers);

        // Filtering even numbers
        List<Integer> evenNumbers = numbers.stream()
                .filter(n -> n % 2 == 0)
                .toList();

        System.out.println("Even numbers: " + evenNumbers);
    }
}







