package in.Code;

/*
	Write a Java program that implements a producer-consumer model using
multithreading. The program should have a producer thread that generates random
numbers and adds them to a queue, and a consumer thread that reads numbers
from the queue and calculates their sum. The program should use synchronization to
ensure that the queue is accessed by only one thread at a time
	 
 */
import java.util.LinkedList;
import java.util.Queue;

public class ProducerConsumerDemo {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();
        int queueCapacity = 10;
        
        Producer producer = new Producer(queue, queueCapacity);
        Consumer consumer = new Consumer(queue);
        
        Thread producerThread = new Thread(producer);
        Thread consumerThread = new Thread(consumer);
        
        producerThread.start();
        consumerThread.start();
    }
}

class Producer implements Runnable {
    private final Queue<Integer> queue;
    private final int queueCapacity;
    
    public Producer(Queue<Integer> queue, int queueCapacity) {
        this.queue = queue;
        this.queueCapacity = queueCapacity;
    }
    
    public void run() {
        while (true) {
            synchronized (queue) {
                while (queue.size() == queueCapacity) {
                    try {
                        queue.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                
                int num = (int) (Math.random() * 100);
                queue.add(num);
                System.out.println("Produced: " + num);
                
                queue.notifyAll();
            }
        }
    }
}

class Consumer implements Runnable {
    private final Queue<Integer> queue;
    
    public Consumer(Queue<Integer> queue) {
        this.queue = queue;
    }
    
    public void run() {
        while (true) {
            synchronized (queue) {
                while (queue.isEmpty()) {
                    try {
                        queue.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                
                int sum = 0;
                while (!queue.isEmpty()) {
                    sum += queue.poll();
                }
                System.out.println("Consumed sum: " + sum);
                
                queue.notifyAll();
            }
        }
    }
}
