package in.Code;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import in.Util.HibernateUtil;

public class HibernateCode {
    public static void main(String[] args) {
    	Session session = null;
		try {
			session = HibernateUtil.getSession();

			@SuppressWarnings("unchecked")
			List<EntityClass> entities = session.createQuery("FROM in.Code.EntityClass").getResultList();

			// process the List Object
			entities.forEach(System.out::println);

		} catch (HibernateException he) {
			he.printStackTrace();
		} finally {
			HibernateUtil.closeSession(session);
			HibernateUtil.closeSessionFactory();
		}
    }
}
