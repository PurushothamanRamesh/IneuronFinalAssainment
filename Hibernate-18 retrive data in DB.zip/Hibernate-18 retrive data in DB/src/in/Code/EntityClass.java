package in.Code;

import javax.persistence.*;

@Entity
@Table(name = "hiber1")
public class EntityClass {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "column1")
	private String column1;

	@Column(name = "column2")
	private String column2;

	public EntityClass() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getColumn1() {
		return column1;
	}

	public void setColumn1(String column1) {
		this.column1 = column1;
	}

	public String getColumn2() {
		return column2;
	}

	public void setColumn2(String column2) {
		this.column2 = column2;
	}

	@Override
	public String toString() {
		return "EntityClass [id=" + id + ", column1=" + column1 + ", column2=" + column2 + "]";
	}

}
