package in.Code;

 public class Parent {
    public Parent() {
        System.out.println("Parent class constructor invoked");
    }
}