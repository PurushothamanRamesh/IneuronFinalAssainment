package in.Code;
/*
	Write a Java program to invoke parent class constructor from a child class. Create
Child class object and parent class constructor must be invoked. Demonstrate by
writing a program. Also explain key points about Constructor.

 
 */

public class Main {
    public static void main(String[] args) {
        Child child = new Child();
    }
}

/*
 * Key points about constructors:
 * 
 * 1  Constructors are special methods in a class that are used to initialize objects of that class. 
 * 2  The name of a constructor must be the same as the class name. 
 * 3  Constructors don't have a return type, not even void.
 * 4  If a class doesn't explicitly define a constructor, a default constructor (with no parameters) is automatically provided by the compiler. 
 * 5  Inheritance allows a child class to inherit the members (including constructors) of its parent
 *    class. When a child class is instantiated, the constructor of its parent
 *    class is called implicitly using the super() statement. 
 * 6  If the parent class has multiple constructors, the child class constructor can explicitly call a
 *    specific parent class constructor using super(arguments).
 */






