package in.Code;

public class Child extends Parent {
    public Child() {
        super(); // Invoking the parent class constructor
        System.out.println("Child class constructor invoked");
    }
}