package in.Code;
/*	
 * Demonstrate the difference between abstract class and interface by writing programs
	as well as in keypoints 
 */

abstract class Animal {
    private String name;

    public Animal(String name) {
        this.name = name;
    }

    public abstract void makeSound();

    public void sleep() {
        System.out.println(name + " is sleeping");
    }
}

class Dog extends Animal {
    public Dog(String name) {
        super(name);
    }

    public void makeSound() {
        System.out.println("Dog barks");
    }
}

public class MainForAbstraction {
    public static void main(String[] args) {
        Animal dog = new Dog("Tommy");
        dog.makeSound();
        dog.sleep();
    }
}

