package in.Code;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import in.Code.util.JdbcUtil;

public class Dao {
	static Connection connection=null;
	PreparedStatement pstmt=null;
	ResultSet resultSet=null;
	private Employee employee;
	private ArrayList<Employee> arrayList;
	
	 public List<Employee> operation() {	
		 arrayList = new ArrayList<>();
		 try {
				connection = JdbcUtil.getJdbcConnection();

				String sqlInsertQuery="SELECT * FROM employees";
				if (connection != null) {
					 pstmt = connection.prepareStatement(sqlInsertQuery);
				}
				if (pstmt != null) {
					resultSet = pstmt.executeQuery();
				}
				while(resultSet.next()){  
					int id=resultSet.getInt(1);
					String name=resultSet.getString(2);
					int age=resultSet.getInt(3);
					employee = new Employee(id, name, age);
				    arrayList.add(employee);
				} 
			} catch (Exception  e) {
				e.printStackTrace();
			}
		return arrayList;
	 }
   
}
   