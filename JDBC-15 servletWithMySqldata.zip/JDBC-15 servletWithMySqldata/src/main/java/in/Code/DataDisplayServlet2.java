package in.Code;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/displayData")
public class DataDisplayServlet2 extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Dao dao;
	private List<Employee> data;
	RequestDispatcher rd = null;

	

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/jsp");
		 PrintWriter out = response.getWriter();
		dao = new Dao();
		data = dao.operation();
		out.println("ID                            NAME                         AGE ");
		for (Employee employee : data) {
			
			out.print (employee.getId() +"                           ");
			out.print(employee.getName()+"                           " );
			out.println(employee.getAge() );
			
           
		}
	}
	
}
