
package in.Code.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class JdbcUtil {
	static Connection connection=null;

	private JdbcUtil() {
	}

	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException ce) {
			ce.printStackTrace();
		}
	}

	public static Connection getJdbcConnection() throws SQLException, IOException {

		FileInputStream inputStream = new FileInputStream(
				"F:\\Full stack Developer\\Code\\JDBC-15 servletWithMySqldata\\src\\main\\java\\in\\properties\\aap.properties");
		Properties p = new Properties();
		p.load(inputStream);
		 connection = DriverManager.getConnection(p.getProperty("url"), p.getProperty("username"),
				p.getProperty("password"));
		return connection;
	}
	
	public void closeConnection() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }
	
	
	
	
	
}